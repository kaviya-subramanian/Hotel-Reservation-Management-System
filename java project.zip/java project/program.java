import java.util.*;
import java.text.*;
class Room {
    private int roomNumber;
    private boolean isAvailable;
    private double pricePerNight;

    public Room(int roomNumber, double pricePerNight) {
        this.roomNumber = roomNumber;
        this.isAvailable = true;  // By default, rooms are available
        this.pricePerNight = pricePerNight;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailability(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public void checkAvailability() {
        if (isAvailable()) {
            System.out.println("Room " + roomNumber + " is available.");
        } else {
            System.out.println("Room " + roomNumber + " is not available.");
        }
    }
}

// Subclasses for different room types
class SingleRoom extends Room {
    public SingleRoom(int roomNumber, double pricePerNight) {
        super(roomNumber, pricePerNight);
    }
}

class DoubleRoom extends Room {
    public DoubleRoom(int roomNumber, double pricePerNight) {
        super(roomNumber, pricePerNight);
    }
}

class SuiteRoom extends Room {
    public SuiteRoom(int roomNumber, double pricePerNight) {
        super(roomNumber, pricePerNight);
    }
}

// Booking class
class Booking {
    private Room room;
    private Date checkIn;
    private Date checkOut;
    private double billingAmount;

    public Booking(Room room, Date checkIn, Date checkOut) {
        this.room = room;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.billingAmount = calculateBillingAmount();
        room.setAvailability(false);  // Room becomes unavailable after booking
    }

    private double calculateBillingAmount() {
        long duration = (checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24);
        if (duration == 0) {
            duration = 1; // Ensure at least one day is billed
        }
        return duration * room.getPricePerNight();
    }

    public void checkout() {
        room.setAvailability(true);  // Room becomes available after checkout
    }

    public double getBillingAmount() {
        return billingAmount;
    }

    public Date getCheckIn() {
        return checkIn;
    }

    public Date getCheckOut() {
        return checkOut;
    }

    public Room getRoom() {
        return room;
    }
}

// Main class
public class HotelReservationSystem {
    private List<Room> rooms = new ArrayList<>();
    private List<Booking> bookings = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public Room findAvailableRoom() {
        for (Room room : rooms) {
            if (room.isAvailable()) {
                return room;
            }
        }
        return null;
    }

    public Booking bookRoom(Date checkIn, Date checkOut) {
        Room availableRoom = findAvailableRoom();
        if (availableRoom != null) {
            Booking booking = new Booking(availableRoom, checkIn, checkOut);
            bookings.add(booking);
            return booking;
        } else {
            System.out.println("No rooms available.");
            return null;
        }
    }

    public void displayBookings() {
        for (Booking booking : bookings) {
            System.out.println("Room Number: " + booking.getRoom().getRoomNumber());
            System.out.println("Check-In: " + booking.getCheckIn());
            System.out.println("Check-Out: " + booking.getCheckOut());
            System.out.println("Billing Amount: $" + booking.getBillingAmount());
            System.out.println("---------------------------");
        }
    }

    // Method to get date input from user
    public Date getDateInput(String prompt) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        while (date == null) {
            System.out.print(prompt);
            String dateStr = scanner.nextLine();
            try {
                date = sdf.parse(dateStr);
            } catch (ParseException e) {
                System.out.println("Invalid date format. Please enter in yyyy-MM-dd format.");
            }
        }
        return date;
    }

    // Method to display all available rooms
    public void displayAvailableRooms() {
        System.out.println("Available Rooms:");
        for (Room room : rooms) {
            if (room.isAvailable()) {
                System.out.println("Room Number: " + room.getRoomNumber() + " - Price per night: $" + room.getPricePerNight());
            }
        }
    }

    // Main method to run the program
    public static void main(String[] args) {
        HotelReservationSystem hotel = new HotelReservationSystem();

        // Adding more rooms with different types
        hotel.addRoom(new SingleRoom(101, 100.0));
        hotel.addRoom(new SingleRoom(102, 110.0));
        hotel.addRoom(new DoubleRoom(201, 150.0));
        hotel.addRoom(new DoubleRoom(202, 160.0));
        hotel.addRoom(new SuiteRoom(301, 250.0));
        hotel.addRoom(new SuiteRoom(302, 270.0));
        hotel.addRoom(new SuiteRoom(303, 300.0));
        hotel.addRoom(new SingleRoom(104, 105.0));
        hotel.addRoom(new DoubleRoom(203, 155.0));
        hotel.addRoom(new SuiteRoom(304, 280.0));

        // Display all available rooms before booking
        hotel.displayAvailableRooms();

        // Get user input for room booking
        Scanner scanner = new Scanner(System.in);

        // Ask for check-in and check-out dates
        Date checkIn = hotel.getDateInput("Enter Check-In date (yyyy-MM-dd): ");
        Date checkOut = hotel.getDateInput("Enter Check-Out date (yyyy-MM-dd): ");

        // Ask user to select room type
        System.out.println("Choose room type to book:");
        System.out.println("1. Single Room");
        System.out.println("2. Double Room");
        System.out.println("3. Suite Room");
        int roomTypeChoice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Room selectedRoom = null;
        switch (roomTypeChoice) {
            case 1:
                selectedRoom = hotel.findAvailableRoom();  // This would be a SingleRoom
                break;
            case 2:
                selectedRoom = hotel.findAvailableRoom();  // This would be a DoubleRoom
                break;
            case 3:
                selectedRoom = hotel.findAvailableRoom();  // This would be a SuiteRoom
                break;
            default:
                System.out.println("Invalid selection.");
                return;
        }

        if (selectedRoom != null) {
            Booking booking = hotel.bookRoom(checkIn, checkOut);
            System.out.println("Booking successful for Room " + booking.getRoom().getRoomNumber() +
                               ". Billing Amount: $" + booking.getBillingAmount());
        } else {
            System.out.println("No room of the selected type is available.");
        }

        // Display all bookings after booking
        hotel.displayBookings();
    }
}
